from django.db import models

# Create your models here.
from django.contrib.auth.models import User 

class profile(models.Model):
    user = models.OneToOneField(User, on_delete = models.CASCADE)

    name=models.CharField(default = 'SUHEILA (Default)' , max_length = 200 , null = True)

    title =models.CharField(default = 'This is default title change it in profile', max_length = 200, null= True)

    desc_text = 'Hey, there this is a default text description about you that you can change on after clicking on "edit"' 

    desc = models.CharField(default = desc_text, max_length = 200 , null = True)

   
    
    profile_image = models.ImageField(default='media/cc.jpg', upload_to ='media', null = True , blank =  True)


    def __str__(self):
        return f"{self.user.username}'s profile"